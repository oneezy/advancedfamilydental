@echo off
powershell.exe -NoProfile -File "%~dp0Preview.ps1"
if errorlevel 1 pause
