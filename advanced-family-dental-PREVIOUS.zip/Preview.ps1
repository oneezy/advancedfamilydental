param([switch]$NoBrowser, [int]$Port = 0)
$ErrorActionPreference = 'Stop'
$siteRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, $Port)
$types = @{
    '.html'='text/html; charset=utf-8'; '.css'='text/css'; '.js'='text/javascript'
    '.json'='application/json'; '.webmanifest'='application/manifest+json'
    '.svg'='image/svg+xml'; '.png'='image/png'; '.jpg'='image/jpeg'
    '.jpeg'='image/jpeg'; '.webp'='image/webp'; '.ico'='image/x-icon'
    '.woff'='font/woff'; '.woff2'='font/woff2'; '.xml'='application/xml'; '.txt'='text/plain'
}
try {
    $listener.Start()
    $url = 'http://127.0.0.1:{0}/' -f $listener.LocalEndpoint.Port
    Write-Host "Preview: $url"
    Write-Host 'Keep this window open. Press Ctrl+C to stop.'
    if (-not $NoBrowser) { Start-Process $url }
    while ($true) {
        $client = $listener.AcceptTcpClient()
        try {
            $client.ReceiveTimeout = 3000
            $stream = $client.GetStream()
            $reader = [IO.StreamReader]::new($stream, [Text.Encoding]::ASCII, $false, 1024, $true)
            $request = $reader.ReadLine()
            if (-not $request) { continue }
            while ($reader.ReadLine()) {}
            $method, $target = $request.Split(' ')[0..1]
            $relative = [Uri]::UnescapeDataString(($target -split '\?')[0]).TrimStart('/')
            $path = [IO.Path]::GetFullPath([IO.Path]::Combine($siteRoot, $relative.Replace('/', '\')))
            if ([IO.Directory]::Exists($path)) { $path = [IO.Path]::Combine($path, 'index.html') }
            $inside = $path.StartsWith($siteRoot + '\', [StringComparison]::OrdinalIgnoreCase)
            $status = '200 OK'
            $mime = 'text/plain; charset=utf-8'
            if ($method -notin @('GET', 'HEAD')) {
                $status = '405 Method Not Allowed'; $body = [Text.Encoding]::UTF8.GetBytes('Method not allowed')
            } elseif (-not $inside -or -not [IO.File]::Exists($path)) {
                $status = '404 Not Found'; $body = [Text.Encoding]::UTF8.GetBytes('Not found')
            } else {
                $body = [IO.File]::ReadAllBytes($path)
                $mime = $types[[IO.Path]::GetExtension($path).ToLowerInvariant()]
                if (-not $mime) { $mime = 'application/octet-stream' }
            }
            $header = [Text.Encoding]::ASCII.GetBytes("HTTP/1.1 $status`r`nContent-Type: $mime`r`nContent-Length: $($body.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n")
            $stream.Write($header, 0, $header.Length)
            if ($method -ne 'HEAD') { $stream.Write($body, 0, $body.Length) }
        } catch { Write-Verbose $_ } finally { $client.Dispose() }
    }
} finally { $listener.Stop() }
